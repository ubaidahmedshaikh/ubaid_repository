<?php
namespace DeepCopy\Exception;

class CloneException extends \UnexpectedValueException
{
} 