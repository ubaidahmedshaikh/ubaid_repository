CMake Release Notes
*******************

..
  This file should include the adjacent "dev.txt" file
  in development versions but not in release versions.

Releases
========

.. toctree::
   :maxdepth: 1

   3.5 <3.5>
   3.4 <3.4>
   3.3 <3.3>
   3.2 <3.2>
   3.1 <3.1>
   3.0 <3.0>
