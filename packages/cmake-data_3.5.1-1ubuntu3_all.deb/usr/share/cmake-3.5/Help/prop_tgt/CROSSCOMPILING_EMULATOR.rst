CROSSCOMPILING_EMULATOR
-----------------------

Use the given emulator to run executables created when crosscompiling.  This
command will be added as a prefix to :command:`add_test` test commands for
built target system executables.
