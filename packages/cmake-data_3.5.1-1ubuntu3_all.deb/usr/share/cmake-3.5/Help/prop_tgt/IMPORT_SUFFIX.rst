IMPORT_SUFFIX
-------------

What comes after the import library name.

Similar to the target property SUFFIX, but used for import libraries
(typically corresponding to a DLL) instead of regular libraries.  A
target property that can be set to override the suffix (such as
".lib") on an import library name.
