RUNTIME_OUTPUT_NAME
-------------------

.. |XXX| replace:: :ref:`RUNTIME <Runtime Output Artifacts>`
.. |xxx| replace:: runtime
.. include:: XXX_OUTPUT_NAME.txt

See also the :prop_tgt:`RUNTIME_OUTPUT_NAME_<CONFIG>` target property.
