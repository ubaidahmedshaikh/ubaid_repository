FRAMEWORK_VERSION
-----------------

Version of a framework created using the :prop_tgt:`FRAMEWORK` target
property (e.g. ``A``).

This property only affects OS X, as iOS doesn't have versioned
directory structure.
