IMPORTED_LINK_DEPENDENT_LIBRARIES_<CONFIG>
------------------------------------------

<CONFIG>-specific version of IMPORTED_LINK_DEPENDENT_LIBRARIES.

Configuration names correspond to those provided by the project from
which the target is imported.  If set, this property completely
overrides the generic property for the named configuration.
