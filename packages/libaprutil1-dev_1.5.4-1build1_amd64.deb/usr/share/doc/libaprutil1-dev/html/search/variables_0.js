var searchData=
[
  ['alloc_5flen',['alloc_len',['../structapr__bucket__heap.html#ae373dada96f2e005a6aaf80e41c4cf6d',1,'apr_bucket_heap']]],
  ['apr_5fbucket_5ftype_5feos',['apr_bucket_type_eos',['../group___a_p_r___util___bucket___brigades.html#ga829cac9b4843b85a902ddd64dffbfb12',1,'apr_buckets.h']]],
  ['apr_5fbucket_5ftype_5ffile',['apr_bucket_type_file',['../group___a_p_r___util___bucket___brigades.html#ga5f17aa7e616179411a06475ec09626e9',1,'apr_buckets.h']]],
  ['apr_5fbucket_5ftype_5fflush',['apr_bucket_type_flush',['../group___a_p_r___util___bucket___brigades.html#gaecc113cfcc7751dfe70876437a2f51d7',1,'apr_buckets.h']]],
  ['apr_5fbucket_5ftype_5fheap',['apr_bucket_type_heap',['../group___a_p_r___util___bucket___brigades.html#ga2c5608267ed7b860657f5a1c89c2f40d',1,'apr_buckets.h']]],
  ['apr_5fbucket_5ftype_5fimmortal',['apr_bucket_type_immortal',['../group___a_p_r___util___bucket___brigades.html#ga391ac24b2c85969e8efa504588b364bb',1,'apr_buckets.h']]],
  ['apr_5fbucket_5ftype_5fmmap',['apr_bucket_type_mmap',['../group___a_p_r___util___bucket___brigades.html#ga63f9ce8e4d6e796921aad14a218a3b23',1,'apr_buckets.h']]],
  ['apr_5fbucket_5ftype_5fpipe',['apr_bucket_type_pipe',['../group___a_p_r___util___bucket___brigades.html#ga334a875abb2908364a40abbfa80c401f',1,'apr_buckets.h']]],
  ['apr_5fbucket_5ftype_5fpool',['apr_bucket_type_pool',['../group___a_p_r___util___bucket___brigades.html#ga87bace819fdbf07c12497a8289b3567b',1,'apr_buckets.h']]],
  ['apr_5fbucket_5ftype_5fsocket',['apr_bucket_type_socket',['../group___a_p_r___util___bucket___brigades.html#gaa6d9978cc10895bdf0a4686728822a84',1,'apr_buckets.h']]],
  ['apr_5fbucket_5ftype_5ftransient',['apr_bucket_type_transient',['../group___a_p_r___util___bucket___brigades.html#ga1692ced61c1966e67adc05ec2a69ce9b',1,'apr_buckets.h']]],
  ['apr_5fhook_5fdebug_5fcurrent',['apr_hook_debug_current',['../group___a_p_r___util___hook.html#ga37be3c217439ceddbda16054b020a658',1,'apr_hooks.h']]],
  ['apr_5fhook_5fdebug_5fenabled',['apr_hook_debug_enabled',['../group___a_p_r___util___hook.html#ga59309caeb9b47d921727530494f264be',1,'apr_hooks.h']]],
  ['apr_5fhook_5fglobal_5fpool',['apr_hook_global_pool',['../group___a_p_r___util___hook.html#ga8911bb699a5f03ad3c36d579ca0eca23',1,'apr_hooks.h']]],
  ['attr',['attr',['../structapr__xml__elem.html#aa9c71585c0b2a32269852047aebdd61c',1,'apr_xml_elem']]]
];
