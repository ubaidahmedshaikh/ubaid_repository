var searchData=
[
  ['get_5fentry',['get_entry',['../structapr__dbd__driver__t.html#abfe9e7ea9093304d13593fcbc893e06c',1,'apr_dbd_driver_t']]],
  ['get_5fhits',['get_hits',['../structapr__memcache__stats__t.html#a6d3b60bc77c024259a2e9dfb1e35bfd7',1,'apr_memcache_stats_t']]],
  ['get_5fmisses',['get_misses',['../structapr__memcache__stats__t.html#affaa2901db1db585fca3cfa77fcb0230',1,'apr_memcache_stats_t']]],
  ['get_5fname',['get_name',['../structapr__dbd__driver__t.html#af172d65218857de1433910b92365061e',1,'apr_dbd_driver_t']]],
  ['get_5frow',['get_row',['../structapr__dbd__driver__t.html#ad7257c26c42d4f399d9a1ab04cc6c17a',1,'apr_dbd_driver_t']]],
  ['getusednames',['getusednames',['../structapr__dbm__type__t.html#a2fc5fed0a3353db2ba24cd8da6da04e8',1,'apr_dbm_type_t']]]
];
