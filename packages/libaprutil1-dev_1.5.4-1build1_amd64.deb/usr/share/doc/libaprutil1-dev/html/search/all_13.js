var searchData=
[
  ['value',['value',['../structapr__xml__attr.html#a12f0f611e426fe83704de92b3b11d2e3',1,'apr_xml_attr']]],
  ['version',['version',['../structapr__memcache__stats__t.html#a5fa17a72064c6b5ae0624f5945fceea7',1,'apr_memcache_stats_t']]]
];
