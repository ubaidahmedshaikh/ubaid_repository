var searchData=
[
  ['resource_20list_20routines',['Resource List Routines',['../group___a_p_r___util___r_l.html',1,'']]],
  ['relocatable_20memory_20management_20routines',['Relocatable Memory Management Routines',['../group___a_p_r___util___r_m_m.html',1,'']]]
];
