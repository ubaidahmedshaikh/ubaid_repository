var searchData=
[
  ['date_20routines',['Date routines',['../group___a_p_r___util___date.html',1,'']]],
  ['dbd_20routines',['DBD routines',['../group___a_p_r___util___d_b_d.html',1,'']]],
  ['dbm_20routines',['DBM routines',['../group___a_p_r___util___d_b_m.html',1,'']]]
];
