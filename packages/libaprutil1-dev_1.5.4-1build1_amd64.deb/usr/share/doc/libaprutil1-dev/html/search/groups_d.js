var searchData=
[
  ['uri',['URI',['../group___a_p_r___util___u_r_i.html',1,'']]],
  ['uuid_20handling',['UUID Handling',['../group___a_p_r___u_u_i_d.html',1,'']]]
];
