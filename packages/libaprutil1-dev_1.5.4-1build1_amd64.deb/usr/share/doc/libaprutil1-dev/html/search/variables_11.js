var searchData=
[
  ['text',['text',['../structapr__text.html#a37a262695c36f740a7777ea9dd0b699d',1,'apr_text']]],
  ['threads',['threads',['../structapr__memcache__stats__t.html#a4e2a4875902e032a56de9ac58315f372',1,'apr_memcache_stats_t']]],
  ['time',['time',['../structapr__memcache__stats__t.html#adc02da0e6bfc619cd7eaebfae94404ff',1,'apr_memcache_stats_t']]],
  ['tm',['tm',['../unionapr__anylock__t_1_1apr__anylock__u__t.html#af08254c9ff8d2152276040037cd8ee53',1,'apr_anylock_t::apr_anylock_u_t']]],
  ['total_5fconnections',['total_connections',['../structapr__memcache__stats__t.html#a47413a65552fa02fcc8adb74b3d0b8c0',1,'apr_memcache_stats_t']]],
  ['total_5fitems',['total_items',['../structapr__memcache__stats__t.html#a298fd199bee38cd658d54f6099e9fb58',1,'apr_memcache_stats_t']]],
  ['transaction_5fmode_5fget',['transaction_mode_get',['../structapr__dbd__driver__t.html#a00d4b7a3362ced55e9b5f0c2513aa284',1,'apr_dbd_driver_t']]],
  ['transaction_5fmode_5fset',['transaction_mode_set',['../structapr__dbd__driver__t.html#a81620ae15072e50976ddca1808efbba4',1,'apr_dbd_driver_t']]],
  ['type',['type',['../structapr__bucket.html#ac27fa5ce798e688ad243ebe1615937fc',1,'apr_bucket::type()'],['../structapr__dbm__t.html#a27287213e7ebe16d9945207a13300faf',1,'apr_dbm_t::type()']]]
];
