<?php
// $Header$

/**
 * @package phpLDAPadmin
 */

# You should secure your PLA by making the htdocs/ your docroot.
header('Location: htdocs/index.php');
die();
?>
