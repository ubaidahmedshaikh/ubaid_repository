/* includes/sys/sdt-config.h.  Generated from sdt-config.h.in by configure.

   This file just defines _SDT_ASM_SECTION_AUTOGROUP_SUPPORT to 0 or 1 to
   indicate whether the assembler supports "?" in .pushsection directives.  */

#define _SDT_ASM_SECTION_AUTOGROUP_SUPPORT 1
