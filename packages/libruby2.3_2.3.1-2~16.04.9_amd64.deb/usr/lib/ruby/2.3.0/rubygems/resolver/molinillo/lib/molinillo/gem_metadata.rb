# frozen_string_literal: false
module Gem::Resolver::Molinillo
  VERSION = '0.4.0'
end
