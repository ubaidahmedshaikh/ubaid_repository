var searchData=
[
  ['library_20initialization_20and_20termination',['Library initialization and termination',['../group__apr__library.html',1,'']]],
  ['local',['local',['../structapr__os__sock__info__t.html#afaf470560cbc3088479af708878aa086',1,'apr_os_sock_info_t']]]
];
