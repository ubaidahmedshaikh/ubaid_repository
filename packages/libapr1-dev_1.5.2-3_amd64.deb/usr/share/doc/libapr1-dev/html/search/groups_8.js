var searchData=
[
  ['library_20initialization_20and_20termination',['Library initialization and termination',['../group__apr__library.html',1,'']]]
];
