module PowerAssert
  VERSION = "0.2.7"
end
