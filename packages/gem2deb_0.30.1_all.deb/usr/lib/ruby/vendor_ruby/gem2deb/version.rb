module Gem2Deb
  VERSION = '0.30.1'
end
