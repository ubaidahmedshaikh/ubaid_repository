<?php
/**
 * Classes and functions for the template engine.
 *
 * @author The phpLDAPadmin development team
 * @package phpLDAPadmin
 */

/**
 * Represents a 'gidNumber' attribute
 *
 * @package phpLDAPadmin
 * @subpackage Templates
 */
class GidAttribute extends Attribute {
}
?>
